Interactive notebooks for CSCAR Python Workshops
